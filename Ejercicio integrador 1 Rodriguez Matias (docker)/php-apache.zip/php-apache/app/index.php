<!DOCTYPE html>
<html lang="en">
	<body>
		<h1>¡Que tal Marcos!</h1>
		<p>----------------------</p>
		<p>|	Bienvenido      |</p>
		<p>----------------------</p>
		<pre id="docker-art">
		##         .
		## ## ##        ==
		## ## ## ## ##    ===
		       /"""""""""""""""""\___/ ===
		       {                       /  ===-
		       \______ O           __/
		       \    \         __/
		        \____\_______/


		<?php $link_name = "Contador"; ?>
		<?php $id = 2; ?>
		<?php echo '<h2>Lo saluda Matias.Le sugiero probar el contador de visitas:</h2>'?>
<a href="contador.php?id=<?php echo $id; ?>"><?php echo $link_name; ?></a>


	</body>
</html>



